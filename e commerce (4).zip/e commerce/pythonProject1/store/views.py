from django.shortcuts import render, get_object_or_404
from .models import Product, Category



def categories(request):
    return {
        'categories': Category.objects.all()
    }


def all_products(request):
    products = Product.objects.all()
    return render(request, 'store/home.html', {'products': products})


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug, in_stock=True)
    return render(request, 'store/detail.html', {'product':product})

def categories_list(request, category_slug):
    if category_slug == 'all':
        products = Product.objects.all()
        category_name = 'All Products'
    else:
        category = get_object_or_404(Category, slug=category_slug)
        products = Product.objects.filter(category=category)
        category_name = category.name
    return render(request, 'store/category.html', {'category_name': category_name, 'products': products})
