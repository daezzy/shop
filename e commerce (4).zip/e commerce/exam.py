### Creterialar:

# - Toza kod.
# - O'tish balli 60.
# - Talab qilingan namuna kodi bo'lishi kerak.
# - Agar nazariya bo'lsa, lekin kodli misol bo'lmasa, u kamroq ball oladi.

# !! Imtihon qoidalari, aldamang, atrofga qaramang!

# !! Savollarga javob yozing va namuna kodini taqdim eting.


### Savollar

1-savol: Pytelegrambotapi kutubxonasidan foydalangan holda foydalanuvchiga fotosuratni qanday yuborish mumkin?

#Javob:

Kodga misol:

2-savol: Send_photo usuli orqali surat yuborishda qanday parametrlarni ko'rsatish mumkin?

#Javob:

Kodga misol:

3-savol: Foydalanuvchi tomonidan yuborilgan fotosuratni qanday qabul qilish va qayta ishlash kerak?

#Javob:

Kodga misol:

#4-savol: Pytelegrambotapida register_next_step_handler nima va u nima uchun ishlatiladi?

#Javob:

Kodga misol:

5-savol: Register_next_step_handler yordamida bir nechta xabarlarni qayta ishlash bosqichlarini qanday bog'lash mumkin?

#Javob:

Kodga misol:

#6-savol: ReplyKeyboardMarkup yordamida shaxsiy klaviatura qanday yaratiladi?

#Javob:

Kodga misol:

7-savol: KeyboardButton yordamida klaviatura uchun tugmalarni qanday yaratish mumkin?

#Javob:

Kodga misol:

8-savol: Telegram botlari kontekstidagi buyruqlar nima?

#Javob:

Kodga misol:

#9-savol: Pytelegrambotapi yordamida botga buyruqlarni qanday qo'shish mumkin?

#Javob:

Kodga misol:

10-savol: Buyruqlarni qayta ishlash funksiyasini qanday amalga oshirish mumkin?

#Javob:

Kodga misol:

11-savol: Pytelegrambotapi-da matn va fotosuratlardan tashqari qanday turdagi kontent (xabarlar) qo'llab-quvvatlanadi?

#Javob:

Kodga misol:

#12-savol: Pytelegrambotapida send_audio usuli yordamida foydalanuvchiga audio faylni qanday yuborish mumkin?

#Javob:

Kodga misol:

13-savol: Telegram API ga pytelegrambotapi kutubxonasidan qanday ulanish mumkin?

#Javob:

Kodga misol:

#14-savol: Qanday qilib pytelegrambotapi yordamida foydalanuvchiga stiker yuborishim mumkin?

#Javob:

Kodga misol:

15-savol: Telegramda qanday qilib bot yaratish va pytelegrambotapi orqali bot bilan ishlash uchun token olish mumkin?

#Javob:

Kodga misol: